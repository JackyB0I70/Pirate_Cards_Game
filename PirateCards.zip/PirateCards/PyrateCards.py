import tkinter as tk
from tkinter import PhotoImage
import random
import time
import threading

# Global Variables
cards_flipped_count = 0
first_card_name = ""
first_card = None
second_card = None
is_match = False
Flipped_num = 0

timer = 0
end_time = 0

# Create Card Class
class Card:
    def __init__(self, name, face):
        self.name = name
        self.face = face

# Functions
def create_deck():
    card_deck = []
    for i in range(2):
        card_deck.append(Card("sword", PhotoImage(file="im_sword.png")))
        card_deck.append(Card("hat", PhotoImage(file="im_hat.png")))
        card_deck.append(Card("treasure", PhotoImage(file="im_treasure.png")))
        card_deck.append(Card("boat", PhotoImage(file="im_boat.png")))
    random.shuffle(card_deck)
    card_deck.append(Card("back", PhotoImage(file="im_cardback.png")))
    return card_deck

def start_timer():
    global timer
    while Flipped_num < 4:
        time.sleep(1)
        timer += 1

def stop_timer():
    global end_time
    end_time = timer
    minutes = end_time // 60
    seconds = end_time % 60
    formatted_time = "{:02d}:{:02d}".format(minutes, seconds)
    return formatted_time

def Thread_delay():
    time.sleep(1)
    Card1.config(state=tk.NORMAL)
    Card2.config(state=tk.NORMAL)
    Card3.config(state=tk.NORMAL)
    Card4.config(state=tk.NORMAL)
    Card5.config(state=tk.NORMAL)
    Card6.config(state=tk.NORMAL)
    Card7.config(state=tk.NORMAL)
    Card8.config(state=tk.NORMAL)
    global is_match
    if is_match:
        global first_card
        first_card.place(y=1000)
        global second_card
        second_card.place(y=1000)
        global cards_flipped_count
        cards_flipped_count = 0
        is_match = False
        global Flipped_num
        Flipped_num += 1
        if Flipped_num == 4:
            EndL.config(text="VICTORY!")
            titleL.config(text="")
            timeL.config(text=stop_timer())


    else:
        Card1.config(image=card_deck[8].face)
        Card2.config(image=card_deck[8].face)
        Card3.config(image=card_deck[8].face)
        Card4.config(image=card_deck[8].face)
        Card5.config(image=card_deck[8].face)
        Card6.config(image=card_deck[8].face)
        Card7.config(image=card_deck[8].face)
        Card8.config(image=card_deck[8].face)
        cards_flipped_count = 0
        titleL.config(text="")

def flip_card(cardbutton, index):
    cardbutton.config(image=card_deck[index].face)
    global cards_flipped_count
    cards_flipped_count += 1
    if cards_flipped_count == 1:
        global first_card_name
        first_card_name = card_deck[index].name
        global first_card
        first_card = cardbutton

    elif cards_flipped_count == 2:
        global second_card
        second_card = cardbutton
        Card1.config(state=tk.DISABLED)
        Card2.config(state=tk.DISABLED)
        Card3.config(state=tk.DISABLED)
        Card4.config(state=tk.DISABLED)
        Card5.config(state=tk.DISABLED)
        Card6.config(state=tk.DISABLED)
        Card7.config(state=tk.DISABLED)
        Card8.config(state=tk.DISABLED)
        if first_card_name == card_deck[index].name:
            titleL.config(text="MATCH!")
            global is_match
            is_match = True
            t1 = threading.Thread(target=Thread_delay)
            t1.start()

        else:
            t1 = threading.Thread(target=Thread_delay)
            t1.start()

# Create Main Window
frame = tk.Tk()
frame.title("PYRATE CARDS")
frame.geometry("800x800")
frame.config(bg="#075464")
frame.iconbitmap("PirateLogo.ico")

titleL = tk.Label(frame, text="", font="bold 30", fg="green", bg="#075464")
titleL.place(x=300, y=50, width=200, height=30)

EndL = tk.Label(frame, text="", font="bold 40", fg="red", bg="#075464")
EndL.place(x=250, y=300, width=300, height=40)

timeL = tk.Label(frame, text="", font="bold 20", fg="white", bg="#075464")
timeL.place(x=250, y=350, width=300, height=20)

card_deck = create_deck()

# Create Card Interactables
Card1 = tk.Button(frame, image=card_deck[8].face, command=lambda: flip_card(Card1, 0))
Card1.place(x=210, y=150, width=100, height=160)

Card2 = tk.Button(frame, image=card_deck[8].face, command=lambda: flip_card(Card2, 1))
Card2.place(x=320, y=150, width=100, height=160)

Card3 = tk.Button(frame, image=card_deck[8].face, command=lambda: flip_card(Card3, 2))
Card3.place(x=430, y=150, width=100, height=160)

Card4 = tk.Button(frame, image=card_deck[8].face, command=lambda: flip_card(Card4, 3))
Card4.place(x=540, y=150, width=100, height=160)

Card5 = tk.Button(frame, image=card_deck[8].face, command=lambda: flip_card(Card5, 4))
Card5.place(x=210, y=320, width=100, height=160)

Card6 = tk.Button(frame, image=card_deck[8].face, command=lambda: flip_card(Card6, 5))
Card6.place(x=320, y=320, width=100, height=160)

Card7 = tk.Button(frame, image=card_deck[8].face, command=lambda: flip_card(Card7, 6))
Card7.place(x=430, y=320, width=100, height=160)

Card8 = tk.Button(frame, image=card_deck[8].face, command=lambda: flip_card(Card8, 7))
Card8.place(x=540, y=320, width=100, height=160)

t_timer = threading.Thread(target=start_timer)
t_timer.start()

frame.mainloop()
